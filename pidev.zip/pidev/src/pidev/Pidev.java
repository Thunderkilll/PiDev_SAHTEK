/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pidev;

import DB.MyConnection;
import Entite.Medicament;
import Entite.Pharmacie;
import java.sql.Connection;
import java.sql.Date;
import services.ServicesMedicament;
import services.Servicespharmacie;

/**
 *
 * @author lafa
 */
public class Pidev {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       MyConnection.getInstance() ;
      Servicespharmacie sp = new Servicespharmacie();
      ServicesMedicament sm = new ServicesMedicament() ;
      
      //Pharmacie p1 = new Pharmacie(10,"nn11","sfgj@address00",1254582,1566,new java.sql.Date(2015-1900,5,8));
      //Pharmacie p2 = new Pharmacie(11,"nn21","sfgj@address0",25547822,2008,new java.sql.Date(2028-1900,5,8));
      //Pharmacie p3 = new Pharmacie(12,"nn31","sfgj@address1",25547835,8255,new java.sql.Date(2338-1900,6,8));
     // Pharmacie p4 = new Pharmacie(13,"nn41","sfgj@address2",25549955,2080,new java.sql.Date(2025-1900,5,9));
      //sp.ajouterPharmacie(p4);
      //sp.ajouterPharmacie(p3);
      //sp.ajouterPharmacie(p2);
      //sp.ajouterPharmacie(p1);
      //sp.supprimerPharmacie(p4);
      //sp.supprimerPharmacie(p3);
      //sp.supprimerPharmacie(p2);
      //sp.supprimerPharmacie(p1);
      //sp.afficherPharmacie(p3);
      //sp.modifierPharmacie(p4, 5889, ";k;k;");
      //sp.afficherPharmacie(p4);
      //Pharmacie p0 ;
    // p0=sp.chercherPharmacie(13);
        //sSystem.out.println(p0.toString()); 
        
        
        
        
        Medicament m1 = new Medicament(233,"maxilase",233,"dhgcbcc");
        Medicament m2=new Medicament(343,"aspegique",33.2,"elissa");
        Medicament m3=new Medicament(152,"gjhjhgj,",23.2,"yassemine");
        Medicament m4=new Medicament(131,"fgxjhnvl",22.3,"cnjhku");
        
        //sm.ajouterMedicament(m2);
        sm.ajouterMedicament(m1);
        //sm.ajouterMedicament(m3);
       // sm.ajouterMedicament(m4);
       //sm.afficherMedicament(m4);
      // Medicament m0;
      // m0=sm.chercherMedicament(131);
       //System.out.println(m0.toString());
       //sm.modifierMedicament(m3,"gkjhb");
      // sm.supprimerMedicament(m1);
       
        
        
      
    }
    
}
