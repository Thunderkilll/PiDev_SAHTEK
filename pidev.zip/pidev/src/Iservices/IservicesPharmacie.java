/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Iservices;
import Entite.Pharmacie;
/**
 *
 * @author lafa
 */
public interface IservicesPharmacie {
   public void ajouterPharmacie(Pharmacie p);
    public void supprimerPharmacie(Pharmacie p);
    public Pharmacie chercherPharmacie(int id_pharmacie);
    public void afficherPharmacie(Pharmacie p);
     public void modifierPharmacie(Pharmacie p, int code ,String adresse );
     
}
